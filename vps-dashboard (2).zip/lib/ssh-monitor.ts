// Servicio para monitorear los intentos de acceso SSH
import fs from "fs"
import { exec } from "child_process"
import { promisify } from "util"
import { addAccessAttempt } from "./db"

const execAsync = promisify(exec)

// Rutas de archivos de log (ajustar según la configuración del servidor)
const SSH_LOG_PATH = "/var/log/auth.log"
const CUSTOM_LOG_PATH = "/var/log/ssh-attempts.log"

// Expresión regular para detectar intentos de acceso SSH en el puerto 2222
const SSH_ATTEMPT_REGEX =
  /(\w+\s+\d+\s+\d+:\d+:\d+).*sshd\[\d+\]:.*(Failed|Accepted).*from\s+(\d+\.\d+\.\d+\.\d+)\s+port\s+(\d+).*user\s+(\w+)/

// Función para monitorear el archivo de log de SSH
export async function monitorSSHLog() {
  try {
    // Verificar si podemos acceder al archivo de log
    if (!fs.existsSync(SSH_LOG_PATH)) {
      console.warn(`Archivo de log SSH no encontrado: ${SSH_LOG_PATH}`)
      return
    }

    // Leer las últimas líneas del archivo de log
    const { stdout } = await execAsync(`tail -n 100 ${SSH_LOG_PATH}`)

    // Procesar cada línea
    const lines = stdout.split("\n")
    for (const line of lines) {
      const match = line.match(SSH_ATTEMPT_REGEX)
      if (match) {
        const [, timestamp, result, ip, port, user] = match

        // Solo procesar intentos en el puerto 2222
        if (port === "2222") {
          // Convertir el timestamp a formato ISO
          const date = new Date(new Date().getFullYear() + " " + timestamp)

          // Añadir el intento a la base de datos
          await addAccessAttempt({
            ip,
            user,
            port: 2222,
            timestamp: date.toISOString(),
            status: "pending",
            details: `${result} login attempt`,
          })

          console.log(`Nuevo intento de acceso detectado desde ${ip} para el usuario ${user}`)
        }
      }
    }
  } catch (error) {
    console.error("Error al monitorear el log SSH:", error)
  }
}

// Función para simular intentos de acceso (para desarrollo/demostración)
export async function simulateAccessAttempt(ip: string, user: string) {
  const timestamp = new Date().toISOString()

  await addAccessAttempt({
    ip,
    user,
    port: 2222,
    timestamp,
    status: "pending",
    details: "Simulated access attempt",
  })

  console.log(`Intento de acceso simulado desde ${ip} para el usuario ${user}`)
  return true
}
