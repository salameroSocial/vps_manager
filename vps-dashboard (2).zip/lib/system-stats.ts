// Módulo para obtener estadísticas del sistema en tiempo real
import { exec } from "child_process"
import { promisify } from "util"
import os from "os"
import fs from "fs"

const execAsync = promisify(exec)

export interface SystemStats {
  cpu: {
    usage: number
    cores: number
    model: string
    speed: number
  }
  memory: {
    total: number
    used: number
    free: number
    usagePercentage: number
  }
  disk: {
    total: number
    used: number
    free: number
    usagePercentage: number
  }
  network: {
    rx: number
    tx: number
    connections: number
  }
  uptime: {
    system: number
    formatted: string
  }
  loadAverage: number[]
}

// Función para obtener estadísticas del sistema
export async function getSystemStats(): Promise<SystemStats> {
  try {
    // En un entorno de producción, estas estadísticas se obtendrían
    // ejecutando comandos del sistema. Aquí simulamos algunos datos
    // y usamos la API de Node.js para otros.

    // CPU
    let cpuUsage = 0
    try {
      // En Linux podemos usar el comando mpstat
      const { stdout } = await execAsync("mpstat | grep all | awk '{print 100-$13}'")
      cpuUsage = Number.parseFloat(stdout.trim())
    } catch (error) {
      // Fallback: calculamos un valor aproximado basado en la carga
      const loadAvg = os.loadavg()[0]
      const cpuCount = os.cpus().length
      cpuUsage = Math.min(Math.round((loadAvg / cpuCount) * 100), 100)
    }

    // Memoria
    const totalMem = os.totalmem()
    const freeMem = os.freemem()
    const usedMem = totalMem - freeMem
    const memUsagePercentage = Math.round((usedMem / totalMem) * 100)

    // Disco
    let diskStats = {
      total: 1000 * 1024 * 1024 * 1024, // 1TB por defecto
      used: 500 * 1024 * 1024 * 1024, // 500GB por defecto
      free: 500 * 1024 * 1024 * 1024, // 500GB por defecto
      usagePercentage: 50, // 50% por defecto
    }

    try {
      // En Linux podemos usar el comando df
      const { stdout } = await execAsync("df / --output=size,used,avail | tail -1")
      const [total, used, free] = stdout
        .trim()
        .split(/\s+/)
        .map((x) => Number.parseInt(x) * 1024)
      diskStats = {
        total,
        used,
        free,
        usagePercentage: Math.round((used / total) * 100),
      }
    } catch (error) {
      console.error("Error al obtener estadísticas de disco:", error)
      // Usamos los valores por defecto
    }

    // Red
    let networkStats = {
      rx: 1024 * 1024 * 10, // 10MB recibidos por defecto
      tx: 1024 * 1024 * 5, // 5MB enviados por defecto
      connections: 15, // 15 conexiones por defecto
    }

    try {
      // En Linux podemos usar los comandos netstat y cat /proc/net/dev
      const { stdout: netstatOut } = await execAsync("netstat -an | grep ESTABLISHED | wc -l")
      const connections = Number.parseInt(netstatOut.trim())

      // Intentamos leer las estadísticas de red desde /proc/net/dev
      const netDev = fs.readFileSync("/proc/net/dev", "utf8")
      const mainIface = netDev.split("\n").find((line) => line.includes("eth0") || line.includes("ens"))

      if (mainIface) {
        const stats = mainIface.trim().split(/\s+/)
        const rx = Number.parseInt(stats[1])
        const tx = Number.parseInt(stats[9])

        networkStats = {
          rx,
          tx,
          connections,
        }
      } else {
        networkStats.connections = connections
      }
    } catch (error) {
      console.error("Error al obtener estadísticas de red:", error)
      // Usamos los valores por defecto
    }

    // Uptime
    const uptimeSeconds = os.uptime()
    const days = Math.floor(uptimeSeconds / 86400)
    const hours = Math.floor((uptimeSeconds % 86400) / 3600)
    const minutes = Math.floor((uptimeSeconds % 3600) / 60)
    const formattedUptime = `${days}d ${hours}h ${minutes}m`

    return {
      cpu: {
        usage: cpuUsage,
        cores: os.cpus().length,
        model: os.cpus()[0].model,
        speed: os.cpus()[0].speed,
      },
      memory: {
        total: totalMem,
        used: usedMem,
        free: freeMem,
        usagePercentage: memUsagePercentage,
      },
      disk: diskStats,
      network: networkStats,
      uptime: {
        system: uptimeSeconds,
        formatted: formattedUptime,
      },
      loadAverage: os.loadavg(),
    }
  } catch (error) {
    console.error("Error al obtener estadísticas del sistema:", error)
    throw error
  }
}

// Función para obtener estadísticas de firewall
export async function getFirewallStats() {
  try {
    // En un entorno de producción, estas estadísticas se obtendrían
    // ejecutando comandos como 'ufw status' o leyendo logs

    // Simulamos algunos datos para desarrollo
    return {
      status: "active",
      totalRules: 12,
      blockedConnections: 156,
      lastUpdated: new Date().toISOString(),
      topBlockedIPs: [
        { ip: "45.227.255.207", count: 23 },
        { ip: "185.180.143.49", count: 18 },
        { ip: "193.35.18.187", count: 15 },
        { ip: "45.155.205.233", count: 12 },
        { ip: "89.248.165.74", count: 9 },
      ],
    }
  } catch (error) {
    console.error("Error al obtener estadísticas del firewall:", error)
    throw error
  }
}

// Función para obtener estadísticas de SSH
export async function getSSHStats() {
  try {
    // En un entorno de producción, estas estadísticas se obtendrían
    // analizando los logs de SSH o ejecutando comandos

    // Simulamos algunos datos para desarrollo
    return {
      totalAttempts: 278,
      authorizedIPs: 5,
      failedAttempts: 273,
      lastAttempt: new Date().toISOString(),
      topUsernames: [
        { username: "root", count: 156 },
        { username: "admin", count: 67 },
        { username: "ubuntu", count: 34 },
        { username: "user", count: 12 },
        { username: "test", count: 9 },
      ],
    }
  } catch (error) {
    console.error("Error al obtener estadísticas de SSH:", error)
    throw error
  }
}

// Función para formatear bytes a una unidad legible
export function formatBytes(bytes: number, decimals = 2) {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]

  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
}
