import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"
import { verifyUser, getUserByUsername } from "./db"
import { SignJWT, jwtVerify } from "jose"

// Clave secreta para firmar los tokens JWT
// En producción, usar una clave segura y almacenarla en variables de entorno
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-min-32-chars-long!!")

// Duración del token (24 horas)
const TOKEN_EXPIRY = "24h"

// Nombre de la cookie
const AUTH_COOKIE = "vps_admin_auth"

// Interfaz para el payload del token
export interface JWTPayload {
  id: number
  username: string
  role: string
  exp?: number
}

// Función para crear un token JWT
export async function createToken(payload: JWTPayload): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(TOKEN_EXPIRY)
    .sign(JWT_SECRET)
}

// Función para verificar un token JWT
export async function verifyToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload as JWTPayload
  } catch (error) {
    console.error("Error al verificar el token:", error)
    return null
  }
}

// Función para iniciar sesión
export async function login(
  username: string,
  password: string,
): Promise<{ success: boolean; message: string; token?: string }> {
  try {
    const user = await verifyUser(username, password)

    if (!user) {
      return {
        success: false,
        message: "Credenciales inválidas",
      }
    }

    const token = await createToken({
      id: user.id!,
      username: user.username,
      role: user.role,
    })

    return {
      success: true,
      message: "Inicio de sesión exitoso",
      token,
    }
  } catch (error) {
    console.error("Error al iniciar sesión:", error)
    return {
      success: false,
      message: "Error al iniciar sesión",
    }
  }
}

// Función para cerrar sesión
export function logout(): void {
  const cookieStore = cookies()
  cookieStore.delete(AUTH_COOKIE)
}

// Función para obtener el usuario actual desde la cookie
export async function getCurrentUser(): Promise<JWTPayload | null> {
  const cookieStore = cookies()
  const authCookie = cookieStore.get(AUTH_COOKIE)

  if (!authCookie) {
    return null
  }

  return verifyToken(authCookie.value)
}

// Middleware para proteger rutas
export async function authMiddleware(request: NextRequest): Promise<NextResponse | null> {
  // Rutas públicas que no requieren autenticación
  const publicRoutes = ["/login", "/api/auth/login"]

  // Verificar si la ruta actual es pública
  const isPublicRoute = publicRoutes.some((route) => request.nextUrl.pathname.startsWith(route))

  if (isPublicRoute) {
    return null // Permitir acceso a rutas públicas
  }

  // Verificar si hay una cookie de autenticación
  const authCookie = request.cookies.get(AUTH_COOKIE)

  if (!authCookie) {
    // Redirigir a la página de login
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // Verificar el token
  const payload = await verifyToken(authCookie.value)

  if (!payload) {
    // Token inválido, redirigir a la página de login
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // Verificar si el usuario existe y está activo
  const user = await getUserByUsername(payload.username)

  if (!user || !user.active) {
    // Usuario no existe o está inactivo, redirigir a la página de login
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // Usuario autenticado, permitir acceso
  return null
}

// Función para establecer la cookie de autenticación
export function setAuthCookie(token: string): void {
  const cookieStore = cookies()

  // Establecer la cookie con opciones seguras
  cookieStore.set({
    name: AUTH_COOKIE,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    // Expiración en 24 horas
    maxAge: 60 * 60 * 24,
  })
}
