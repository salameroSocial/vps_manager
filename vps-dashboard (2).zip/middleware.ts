import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { authMiddleware } from "./lib/auth"

export async function middleware(request: NextRequest) {
  // Verificar autenticación
  const authResponse = await authMiddleware(request)

  if (authResponse) {
    return authResponse
  }

  return NextResponse.next()
}

// Configurar las rutas que deben ser protegidas
export const config = {
  matcher: [
    /*
     * Coincide con todas las rutas excepto:
     * 1. /api/auth/* (rutas de autenticación)
     * 2. /login (página de login)
     * 3. /_next (archivos estáticos de Next.js)
     * 4. /favicon.ico, /robots.txt, etc.
     */
    "/((?!api/auth|login|_next|favicon.ico|robots.txt).*)",
  ],
}
